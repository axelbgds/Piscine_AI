# Coucou This is README file

I made this mini package in order to practice Python, thank you for downloading it!
And please follow my github ;-) (https://github.com/mgkgng)